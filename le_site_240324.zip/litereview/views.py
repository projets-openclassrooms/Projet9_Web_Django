from django.http import HttpResponse
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required
from django.template import loader
from django.views.decorators.http import require_GET, require_POST
from . import forms


# Create your views here.
def index(request):
    template = loader.get_template('base.html')
    # return HttpResponse(template.render()
    return render(request, 'index.html', context={})


def logout_page(request):
    logout(request)
    return redirect("login")


def signup(request):
    logout(request)
    return redirect("login")
