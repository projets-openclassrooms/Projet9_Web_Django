from litereview.models import Ticket, Review
from django import forms
from django.contrib.auth.forms import UserCreationForm

from .models import User


class LoginForm(forms.ModelForm):
    """Collects the requested information to enable an user to log in."""
    username = forms.CharField(max_length=15,
                               label="",
                               widget=forms.TextInput(attrs={
                                   "class": "centered-placeholder",
                                   "placeholder": "Nom d'utilisateur", }))
    password = forms.CharField(max_length=15,
                               label="",
                               widget=forms.PasswordInput(attrs={
                                   "class": "centered-placeholder",
                                   "placeholder": "Mot de passe"}), )


class SignUpForm(UserCreationForm):
    username = forms.CharField(
        label='',
        max_length=30,
        min_length=5,
        required=True,
        widget=forms.TextInput(
            attrs={
                "placeholder": "Username",
                "class": "form-control"
            }
        )
    )

    email = forms.EmailField(
        label='',
        max_length=255,
        required=True,
        widget=forms.EmailInput(
            attrs={
                "placeholder": "Email",
                "class": "form-control"
            }
        )
    )

    password1 = forms.CharField(
        label='',
        max_length=30,
        min_length=8,
        required=True,
        widget=forms.PasswordInput(
            attrs={
                "placeholder": "Password",
                "class": "form-control"
            }
        )
    )

    password2 = forms.CharField(
        label='',
        max_length=30,
        min_length=8,
        required=True,
        widget=forms.PasswordInput(
            attrs={
                "placeholder": "Confirm Password",
                "class": "form-control"
            }
        )
    )

    location = forms.CharField(
        label='',
        max_length=30,
        required=False,
        widget=forms.HiddenInput(
            attrs={
                "display": "none"
            }
        )
    )

    class Meta:
        model = User
        fields = ('username', 'email', 'password1', 'password2', 'location')


class TicketForm(forms.Form):
    pass


class DeleteTicketForm(forms.Form):
    pass


class ReviewForm(forms.ModelForm):
    pass


class DeleteReviewForm(forms.ModelForm):
    pass


class FollowForm(forms.Form):
    pass
